#' a data set describing pws 
#'
#' The \code{pwsData} dataset for queryHistory function 
#' @name pwsData
#' @usage data(pwsData)
#' @docType data
#' @keywords data
#'
"pwsData"

#' a data set describing weather data 
#'
#' The \code{weatherData} dataset for plotWeather and summarizeData function 
#' @name weatherData
#' @docType data
#' @keywords data
#'
"weatherData"